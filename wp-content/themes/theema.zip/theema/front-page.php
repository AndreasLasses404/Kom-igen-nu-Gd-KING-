<?php get_header();
?>




   <!-- HERO -->
   <div class="hero">
      <img src="<?php echo get_theme_file_uri('images\hero-img.jpg')?>" alt="demo image" class="hero__image">
      <p class="hero__title">Kom igen nu Frontpage</p>
   </div>

   <!-- MAIN -->
   <main>
      <div class="container">
         <h2 class="section__title">Nyheter</h2>

         
         
         <?php
         
      

         while(have_posts())
         {
           the_post();


         ?>




         <article class = "content__section">
            <div class="article--left">
               <h3 class="article__heading"><?php the_title()?></h3>
               <?php the_excerpt();?>


               <a href="#" class="btn btn--dark">Läs hela artikeln</a>
            </div>


            <div class="article--right">
               <img src=<?php echo get_theme_file_uri('images\bird-square.jpg')?>" alt="demo image">
            </div>
         </article>
         <?php }  ?>
      </div>
   </main>

<?php get_footer();?>

