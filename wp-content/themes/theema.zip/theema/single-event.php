<?php get_header()?>
<div class="hero">
      <img src="<?php echo get_theme_file_uri('images\hero-img.jpg')?>" alt="demo image" class="hero__image">
      <p class="hero__title">Vi skapar en egen single-event</p>      
   </div>
   <main>
   <div class="container">
         <h2 class="section__title"><?php the_title() ?></h2>
<?php
while(have_posts()){
    the_post();?>
    
   
     
         <article class="content__section">
            <div class="article--left">
               <h3 class="article__heading">Här vare <?php the_title() ?></h3>
               <?php the_content() ?> 

               
            </div>

            <div class="article--right">
               <img src=<?php echo get_theme_file_uri('images\bird-square.jpg')?>" alt="demo image">
            </div>
            </article>
         
   

    
<?php } ?>

<p class = "see__all__events"><a href="<?php echo get_post_type_archive_link('event') ?>">Se alla våra kommande event</a></p>



      </div>
</main>
<?php get_footer()?>


