<?php
    function cms_utitities(){
        wp_enqueue_style('google_fonts', 'https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@300;400;700&family=Montserrat:wght@300;400;700&display=swap');
        wp_enqueue_style('font_awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css');   
        wp_enqueue_style('cms_main_styles', get_stylesheet_uri());
    }

    add_action('wp_enqueue_scripts','cms_utitities');

    function cms_adjust_queries($query){
        if(!is_admin() and is_post_type_archive('event') and $query->is_main_query()){

        
        $today = date('Ymd');
        $query->set('meta_key', 'event_date');
        $query->set('orderby', 'meta_value_nun');
        $query->set('order', 'ASC');
        $query->set('meta_query', array(
            array(
                'key' => 'event_date',
                'compare' => '>=',
                'value' => $today,
                'type' => 'numeric'
            )
        ));
    }
    }
    add_action('pre_get_posts', 'cms_adjust_queries');

   
  

    
function my_acf_load_field( $field ) {
    $field['required'] = true;
    $field['choices'] = array(
        'title'    => 'title',
        
    );
    return $field;
}

// Apply to all fields.
// add_filter('acf/load_field', 'my_acf_load_field');

// Apply to select fields.
// add_filter('acf/load_field/type=select', 'my_acf_load_field');

// Apply to fields named "custom_select".
//add_filter('acf/load_field/name=custom_select', 'my_acf_load_field');

// Apply to field with key "field_123abcf".
add_filter('acf/load_field/key=field_5f8822555bff6', 'my_acf_load_field');

    
    
    
?>