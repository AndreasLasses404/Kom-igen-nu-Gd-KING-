<?php get_header()?>
<div class="hero">
      <img src="<?php echo get_theme_file_uri('images\hero-img.jpg')?>" alt="demo image" class="hero__image">
      <p class="hero__title">Vi skapar en egen page</p>      
   </div>
   <main>
   <div class="container">
         <h2 class="section__title">Välkommen <?php echo wp_get_current_user()-> user_login ?></h2>

         <?php
            $current_user = wp_get_current_user();
            $current_user_login = $current_user->user_login;
            if(empty ($current_user_login)) { 
             ?>
              <a href="<?php echo esc_url("http://king.local/wp-login.php"); ?>"<?php if(is_page('Hem')) echo 'class="current__page"'  ?>>Login Here</a>
             <?php
            } 
            else {
               ?>
               <article class="content_section">
               <div class="article--left">
                  
                  <h3 class="article__heading">Det här är en rubrik</h3>
                  <a href="<?php the_permalink('single-event') ?>"><p class="article__text">Skapa sport</p></a>
                  <p class="article__text">Skapa liga</p>
                  

                  <?php /* The loop */ ?>
                  <?php while ( have_posts() ) : the_post(); ?>
                     
                     <h1><?php the_title(); ?></h1>
                     
                     <?php the_content(); ?>

                     <?php acf_form(); ?>
                     
                     <?php wp_mail('ekstrom.oscar@gmail.com', 'skapa sport', the_content()) ?>

                  <?php endwhile; ?>

                  <?php 
                     if(the_content()!=null)
                     {
                        $table_name="sport";
                        $columnName="Sport_Name";
                        $sportName=the_content();

                        $sql = "INSERT INTO sport (Sport_name) VALUES ('$sportName')";
                        $results = $wpdb->query($sql);
                        $my_id = $wpdb->insert_id;
                        echo $my_id;
                     }
                     ?>
                  <p class="article__text"><?php echo the_content()?></p>
                  <p class="article__text">skapa team</p>
                  <p class="article__text">mina team</p>
               </div>
   
               <div class="article--right">
                  <img src=<?php echo get_theme_file_uri('images\bird-square.jpg')?>" alt="demo image">
               </div>
               </article>
           <?php } ?>
      </div>
</main>
<?php get_footer()?>


